-- manage.lua (Universal stub)
-- Este archivo existe solo para mantener compatibilidad con el .toc.
-- Funciones de gestión avanzadas (si existen) deberían vivir en el Master build.
local addonName, GAT = ...

-- Si algún día quieres lógica aquí para TODOS, este stub es el lugar seguro.
