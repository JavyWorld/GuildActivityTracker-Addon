-- reset_button.lua (Universal stub)
-- En Universal NO hay botón de borrado / reset.
local addonName, GAT = ...
if GAT and GAT.IS_MASTER_BUILD then
    -- Si este archivo existe en tu Master build real, reemplaza este stub ahí.
end
